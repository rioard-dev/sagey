package id.web.riosages.riven;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private WebView webView;
    private String ubuntuPath;
	private File staticPath;
    private static final String UBUNTU_URL = "https://cdimage.ubuntu.com/ubuntu-base/releases/jammy/release/ubuntu-base-22.04.2-base-armhf.tar.gz";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		staticPath = new File(getFilesDir().getAbsolutePath());
        ubuntuPath = getFilesDir().getAbsolutePath() + "/ubuntu";
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(), "Android");

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class WebAppInterface {

        @JavascriptInterface
        public void startSetup() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        File dir = new File(ubuntuPath);
                        if (dir.exists() && dir.list() != null && dir.list().length > 10) {
                            updateStatus("Ubuntu sudah terinstal.");
                            hideLoading();
                            goToTerminal();
                            moveDirectory("cd "+staticPath);
                            return;
                        }

                        if (!dir.exists()) dir.mkdirs();

                        File tarFile = new File(getCacheDir(), "ubuntu.tar.gz");
                        
                        updateStatus("Downloading Ubuntu Base...");
                        downloadFileWithProgress(UBUNTU_URL, tarFile);

                        updateStatus("Extracting Ubuntu... (bisa memakan waktu lama)");
                        extractWithProgress(tarFile);

                        setupBasicConfig();

                        tarFile.delete();
                        updateStatus("Setup Ubuntu selesai!");
                        hideLoading();
                        goToTerminal();
                        
                    } catch (Exception e) {
                        updateStatus("Error: " + e.getMessage());
                        hideLoading();
                    } finally{
                        moveDirectory("cd "+staticPath);
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void runCommand(final String cmd) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String result = executeShell(cmd);
                    sendToJs("onCommandResult", result);
                }
            }).start();
        }
    }
	@JavascriptInterface
    public String pathDefaultDir() {
        return staticPath.getAbsolutePath();
    }
    // ==================== DOWNLOAD DENGAN PROGRESS ====================
    private void downloadFileWithProgress(String urlStr, File dest) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);

        long totalSize = conn.getContentLengthLong();
        long downloaded = 0;

        try (InputStream in = conn.getInputStream();
             OutputStream out = new FileOutputStream(dest)) {

            byte[] buf = new byte[32768];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
                downloaded += len;

                if (totalSize > 0) {
                    int progress = (int) ((downloaded * 100) / totalSize);
                    updateProgress("download", progress);
                }
            }
        }
        updateProgress("download", 100);
    }

    // ==================== EXTRACT DENGAN PROGRESS (sederhana) ====================
    private void extractWithProgress(File tarFile) throws Exception {
        Process process = Runtime.getRuntime().exec(new String[]{
                "/system/bin/sh", "-c",
                "tar -xzf " + tarFile.getAbsolutePath() + " -C " + ubuntuPath
        });

        // Simulasi progress extract
        for (int i = 10; i <= 90; i += 10) {
            Thread.sleep(800);
            updateProgress("extract", i);
        }

        process.waitFor();
        updateProgress("extract", 100);
    }

    private void setupBasicConfig() {
        try {
            new File(ubuntuPath + "/etc").mkdirs();
            writeFile(ubuntuPath + "/etc/resolv.conf", "nameserver 8.8.8.8\nnameserver 8.8.4.4\n");
            writeFile(ubuntuPath + "/etc/hosts", "127.0.0.1 localhost\n");
            writeFile(ubuntuPath + "/etc/hostname", "android-ubuntu\n");

            String sources = "deb http://ports.ubuntu.com/ubuntu-ports jammy main restricted universe multiverse\n" +
                             "deb http://ports.ubuntu.com/ubuntu-ports jammy-updates main restricted universe multiverse\n" +
                             "deb http://ports.ubuntu.com/ubuntu-ports jammy-security main restricted universe multiverse\n";
            writeFile(ubuntuPath + "/etc/apt/sources.list", sources);

            updateStatus("Konfigurasi dasar selesai.");
        } catch (Exception e) {
            updateStatus("Warning konfigurasi: " + e.getMessage());
        }
    }

    private void writeFile(String path, String content) throws IOException {
        try (FileWriter writer = new FileWriter(path)) {
            writer.write(content);
        }
    }

    private String executeShell(String command) {
        StringBuilder output = new StringBuilder();
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"/system/bin/sh", "-c", command});
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream()));

            String line;
            while ((line = reader.readLine()) != null) output.append(line).append("\n");
            while ((line = err.readLine()) != null) output.append("[ERR] ").append(line).append("\n");

            p.waitFor();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
        return output.length() == 0 ? "(no output)" : output.toString();
    }

    // ==================== UI CALLBACK ====================
    private void updateStatus(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("updateStatus('" + msg.replace("'", "\\'") + "')", null);
            }
        });
    }

    private void updateProgress(final String type, final int percent) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("updateProgress('" + type + "', " + percent + ")", null);
            }
        });
    }

    private void hideLoading() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("hideLoading()", null);
            }
        });
    }

    private void goToTerminal() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.evaluateJavascript("goToTerminal()", null);
            }
        });
    }

    private void sendToJs(final String func, final String data) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String escaped = data.replace("\\", "\\\\")
                                     .replace("`", "\\`")
                                     .replace("\n", "\\n")
                                     .replace("'", "\\'");
                webView.evaluateJavascript(func + "(`" + escaped + "`)", null);
            }
        });
    }
    @JavascriptInterface
    public void moveDirectory(String command) {
        if (!command.startsWith("cd ")) return;

        String target = command.substring(3).trim();

        if (target.equals("..")) {
            File parent = staticPath.getParentFile();
            if (parent != null && parent.exists()) {
                    staticPath = parent;
            }
        } else {
            File nextDir = target.startsWith("/") ?
            new File(target) :
            new File(staticPath, target);

            if (nextDir.exists() && nextDir.isDirectory()) {
                staticPath = nextDir;
            } else {
                updateStatus("Error: Folder tidak ditemukan: " + target);
            }
        }

        lineHere(staticPath.getAbsolutePath());
    }
    private void lineHere(String path) {
        if (path == null) return;
        final String escaped = path.replace("\\", "\\\\").replace("'", "\\'");
		
        runOnUiThread(new Runnable (){ 
			@Override
			public void run(){
				webView.evaluateJavascript("LineHere('" + escaped + "')", null);
			}
		});
    }
   
}
